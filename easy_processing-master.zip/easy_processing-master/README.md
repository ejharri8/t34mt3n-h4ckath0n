# easy_processing
Module to allow easy preprocessing of data into a format suitable as input for machine learning library
